window.onload = function()
{
    var suspects = ["bart", "lisa", "homer", "marge", "moe", "ralph"];
    var url = ["../Bart/bart.html", "../Lisa/lisa.html", "../Homer/homer.html", "../Marge/marge.html", "../Moe/moe.html", "../Ralph/ralph.html"]
    for (i = 0; i < suspects.length; i++)
    {
        var yes = document.getElementById(suspects[i]);
        yes.addEventListener("click", function () 
        {
            for (i = 0; i < suspects.length; i++)
            {
                if (this.id == suspects[i])
                {
                    var newWindow = window.open(url[i], "bartwindow", "width=800, height=800");
                    newWindow.addEventListener("load", function ()
                    {
                        
                        var closeButton = newWindow.document.createElement("button");
                        closeButton.innerText = "Click to Close";
                        newWindow.document.getElementById("last").appendChild(closeButton);
                        closeButton.addEventListener("click", function() 
                        {
                            newWindow.close();
                        });
                        
                    });
                }
            }
        });
    }
}
